<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mahad extends Model
{
    protected $table='mahad';
    protected $primaryKey='id_mahad';
    protected $guarded = ['id_mahad'];
    
}
