<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Unduhan extends Model
{
    protected $table='unduhan';
    protected $primaryKey='id_unduhan';
    protected $guarded = ['id_unduhan'];
    
}
