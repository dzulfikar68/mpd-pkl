<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Khotbah extends Model
{
    protected $table='khotbah';
    protected $primaryKey='id_khotbah';
    protected $guarded = ['id_khotbah'];
    
}
