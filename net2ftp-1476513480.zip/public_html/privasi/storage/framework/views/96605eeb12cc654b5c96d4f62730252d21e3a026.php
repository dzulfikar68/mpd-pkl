<?php $__env->startSection("content"); ?>

<div class="container">
    <p></p>
    <div class="panel panel-default">
        <h3 align="center">Register</h3>
        <br>
    </div>
        <?php if(Session::has('message')): ?>
        <span class="label label-danger"><?php echo e(Session::get('message')); ?></span>
        <?php endif; ?>
    <div class="col-md-4"></div>
    <div class="panel-body col-md-4">
        <form role="form" method="post" action="<?php echo e(action('LoginController@tambahlogin')); ?>">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="form-group">
                <label>Username</label>
                <input class="form-control" placeholder="masukkan username" name="username">
            </div>

            <div class="form-group">
                <label>Password</label>
                <input class="form-control" placeholder="masukkan password" name="password">
            </div>
            <button type="submit" class="btn btn-primary">Register</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>