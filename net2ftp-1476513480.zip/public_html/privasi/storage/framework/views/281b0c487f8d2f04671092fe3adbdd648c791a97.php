<?php $__env->startSection("content"); ?>

<!-- Kegiatan -->
<div class="container">

    <div class="row">
        <div class="col-sm-12">
            <h1 class="page-header">Mahad Al Madinah
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(URL::to('')); ?>">Home</a>
                </li>
                <li><a href="<?php echo e(URL::to('kegiatan/')); ?>">Kegiatan</a>
                </li>
                <li class="active">Mahad</li>
            </ol>
        </div>
    </div>
    <!-- /.row -->

    <?php if($mahadAll[0] != null): ?>
    <?php foreach($mahadAll as $index => $mahad): ?>

    <!-- Blog Post Row -->
    <div class="row">
        <div class="col-sm-6">
            <a href="<?php echo e(URL::to('mahad/'.$mahad->id_mahad)); ?>">
                <img class="img-responsive img-hover post-image-small" style="background-image:url(<?php echo e(url('resource/mahad.png')); ?>);" src="<?php echo e(url('foto/'.$mahad->gambar)); ?>" alt="<?php echo e($mahad->gambar); ?>">
            </a>
        </div>
        <div class="col-sm-6">
            <h3>
                <a href="<?php echo e(URL::to('mahad/'.$mahad->id_mahad)); ?>"><?php echo substr(strip_tags($mahad->judul), 0, 75) ?></a>
            </h3>
            <p><?php echo substr(strip_tags($mahad->isi), 0, 350) ?>...</p>
            <a class="btn btn-primary" href="<?php echo e(URL::to('mahad/'.$mahad->id_mahad)); ?>">Read More <i class="fa fa-angle-right"></i></a>
        </div>
    </div>
    <!-- /.row -->

    <hr>

    <?php endforeach; ?>

    <?php else: ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="alert alert-info" role="alert" align="center"><i>Hasil pencarian tidak ditemukan</i></div>
        </div>
    </div>
    <hr>
    <?php endif; ?>

    <strong>Jumlah post: <?php echo e($jumlah); ?></strong>
    
    <div class="paging">
        <?php echo e($mahadAll->links()); ?>

    </div>
    
    <br><br><br><br>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>