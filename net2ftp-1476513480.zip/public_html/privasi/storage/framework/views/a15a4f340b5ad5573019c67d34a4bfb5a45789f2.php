<?php $__env->startSection("content"); ?>

<!-- Kegiatan -->
<div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <div class="row">
        <div class="col-sm-12">
            <h1 class="page-header">Galeri
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(URL::to('')); ?>">Home</a>
                </li>
                <li class="active">Galeri</li>
            </ol>
        </div>
    </div>
    <!-- /.row -->

    <p>Berikut adalah kumpulan <strong>foto-foto</strong> yang dapat dilihat tentang kegiatan yang ada di Masjid Pangeran Diponegoro: </p><br>

    <!-- Related Projects Row -->
    <div class="row">
    <?php if($galeriAll[0] != null): ?>
    <?php foreach($galeriAll as $index => $galeri): ?>
        <div class="col-md-2 col-sm-4 col-xs-6">
            <div class="ultralb">
                <img class="img-responsive img-hover img-related customer-img" src="<?php echo e(url('galeri/'.$galeri->gambar)); ?>" 
                alt="<?php echo e($galeri->judul); ?> <br> <small><i>(<?php echo e($galeri->created_at); ?>)</i></small>">
            </div>
        </div>
    <?php endforeach; ?>
    <?php else: ?>
        <div class="col-sm-12">
            <div class="alert alert-info" role="alert" align="center"><i>Tidak ada foto di Galeri</i></div>
        </div>
    <?php endif; ?>
    </div>
    <!-- /.row -->

    <hr>

    <!-- Pager -->
    <strong>Jumlah foto: <?php echo e($jumlah); ?></strong>
    
    <div class="paging">
        <?php echo e($galeriAll->links()); ?>

    </div>
    
    <br><br><br><br>
    <!-- /.row -->

    <?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>