<?php $__env->startSection("content"); ?>

<!-- Kegiatan -->
<div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Donasi
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(URL::to('')); ?>">Home</a>
                </li>
                <li class="active">Donasi</li>
            </ol>
        </div>
    </div>
    <!-- /.row -->

    <div class="row">
        <div class="col-lg-6">
            <img class="img-responsive img-hover" src="<?php echo e(url('resource/donasi.png')); ?>" alt="">
        </div>
        <div class="col-lg-6">
            <p class="lead">Kami dari Masjid Pangeran Diponegoro menerima donasi infaq berupa uang atau dalam bentuk lain. Dibawah ini adalah prosedur donasi beserta laporan pemasukan dan pengeluaran dana oleh Masjid Pangeran Diponegoro Semarang:</p>
            <p>Apabila pendonasi ingin transfer melalui rekening, bisa melalui <strong>NO.REK ?</strong></p>
        </div>
    </div>
    <!-- /.row -->
    
    <br><br><br>

    <h2 class="page-header">Rekam Laporan Bulanan</h2>

    <div class="table-responsive">
        
        <table class="table table-hover table-striped">
            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
            <thead>
                <tr>
                    <th>Laporan Bulanan (YYYY-MM)</th>
                    <th>Pemasukan</th>
                    <th>Pengeluaran</th>
                    <th>Saldo (Pemasukan - Pengeluaran)</th>
                </tr>
            </thead>
            <tbody>
                <?php if($donasiAll[0] != null): ?>
                    <?php foreach($donasiAll as $index => $donasi): ?>
                        <tr>
                            <td><?php echo e($donasi->tanggal); ?></td>
                            <td>Rp <?php echo e($donasi->masuk); ?></td>
                            <td>Rp <?php echo e($donasi->keluar); ?></td>
                            <td>Rp <?php echo e($donasi->masuk - $donasi->keluar); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" style="text-align: center"><i>Tidak Ada Laporan</i></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="tabel-nav">
        <div class="paging">
            <?php echo e($donasiAll->links()); ?>

        </div>
    </div>
    
    <br><br><br><br>

    <h2 class="page-header">Detail Laporan Terbaru</h2>

    <?php if($excel[0] != null): ?>
    <?php foreach($excel as $index => $ex): ?>
    <iframe class="embed-responsive-item" width="100%" height="500" scrolling="no" frameborder="no" src="https://docs.google.com/spreadsheets/d/<?php echo e($ex->link); ?>/pubhtml?widget=true&amp;headers=false"></iframe>

    <br><br>

    <a type="submit" class="btn btn-primary" href="https://docs.google.com/spreadsheets/d/<?php echo e(url('excel/'.$ex->link)); ?>/pubhtml?widget=true&amp;headers=false">Unduh Berkas</a>
    <?php endforeach; ?>

    <?php else: ?>
    <p class="form-control-static"><i>Tidak ada detail</i></p>

    <?php endif; ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>