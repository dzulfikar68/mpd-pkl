<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-sm-12">
                <h1 class="page-header">
                    Semua Post <small>Kajian Rutin</small> <a type="submit" class="btn btn-xs btn-default" href="<?php echo e(URL::to('kajian/')); ?>" >Petinjau</a>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="<?php echo e(URL::to('admin/')); ?>">Beranda</a>
                    </li>
                    <li>
                        <i class="fa fa-play"></i>  <a href="<?php echo e(URL::to('admin-kajian-all/')); ?>">Kajian</a>
                    </li>
                    <li class="active">
                        Semua Post
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            
            <div class="col-sm-12">
                
                <?php if(Session::has('message')): ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <i class="fa fa-info-circle"></i>  <strong><?php echo e(Session::get('message')); ?></strong>
                </div>
                <?php endif; ?>

                <?php if(Session::has('destroy')): ?>
                <div class="alert alert-success alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <i class="fa fa-info-circle"></i>  <strong><?php echo e(Session::get('destroy')); ?></strong>
                </div>
                <?php endif; ?>
                
                <div><span><strong>
                    Kategori: 
                    <a href="<?php echo e(URL::to('admin-kajian-all/Tauhid')); ?>">Tauhid</a><a>, </a>
                    <a href="<?php echo e(URL::to('admin-kajian-all/Fiqih')); ?>">Fiqih</a><a>, </a>
                    <a href="<?php echo e(URL::to('admin-kajian-all/Akhlak')); ?>">Akhlak</a><a>, </a>
                    <a href="<?php echo e(URL::to('admin-kajian-all/Tafsir')); ?>">Tafsir</a><a>, </a>
                    <a href="<?php echo e(URL::to('admin-kajian-all/Sirah')); ?>">Sirah</a><a>, </a>
                    <a href="<?php echo e(URL::to('admin-kajian-all/Tematik')); ?>">Tematik</a><a>, </a>
                </strong></span></div>
                
                <br>
                
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                        <thead>
                            <tr>
                                <th>Tanggal Buat</th>
                                <th>Judul</th>
                                <th>Kategori</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($kajianAll[0] != null): ?>
                                <?php foreach($kajianAll as $index => $kajian): ?>
                                    <tr>
                                        <td><?php echo e($kajian->created_at); ?></td>
                                        <td><?php echo substr(strip_tags($kajian->judul), 0, 75) ?></td>
                                        <td><?php echo e($kajian->kategori); ?></td>
                                        
                                        <td>
                                            <a type="submit" class="btn btn-sm btn-primary" href="<?php echo e(URL::to('admin-kajian-view/'.$kajian->id_kajian)); ?>">Lihat</a>
                                            <a type="submit" class="btn btn-sm btn-warning" href="<?php echo e(URL::to('admin-kajian-edit/'.$kajian->id_kajian)); ?>">Edit</a>
                                            <a type="submit" class="btn btn-sm btn-danger" href="<?php echo e(URL::to('admin-kajian-delete/'.$kajian->id_kajian)); ?>"> Hapus</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" style="text-align: center"><i>Tidak Ada Kajian</i></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="tabel-nav">
                    <div class="jumlah-data">
                        <strong> Jumlah kajian: <?php echo e($jumlah); ?>

                        </strong>
                    </div>
                    <div class="paging">
                        <?php echo e($kajianAll->links()); ?>

                    </div>
                </div>
                
                <br>
                
                <div>
                    <a type="submit" class="btn btn-primary" href="<?php echo e(URL::to('admin-kajian-add/')); ?>" >Tambah Kajian</a>
                </div>    
            
                <br><br><br><br>

            </div>

        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>