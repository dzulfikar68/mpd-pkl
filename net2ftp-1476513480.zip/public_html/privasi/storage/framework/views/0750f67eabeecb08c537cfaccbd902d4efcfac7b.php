<?php $__env->startSection("content"); ?>

<!-- Kegiatan -->
<div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Unduhan
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(URL::to('')); ?>">Home</a>
                </li>
                <li class="active">Unduhan</li>
            </ol>
        </div>
    </div>
    <!-- /.row -->

    <p>Berikut adalah berkas yang dapat diunduh tentang <strong>berkas-berkas</strong> kegiatan yang ada di Masjid Pangeran Diponegoro: </p><br>

    <?php foreach($unduhan as $index => $undu): ?>
    <iframe class="embed-responsive-item" width="100%" height="500" frameborder="no" src="https://drive.google.com/embeddedfolderview?id=<?php echo e($undu->link); ?>#list" width="700" height="500" frameborder="0"></iframe>
    <?php endforeach; ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>