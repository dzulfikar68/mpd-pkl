<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-sm-12">
                <h1 class="page-header">
                    Lihat Post <small>Kajian Rutin</small> <a type="submit" class="btn btn-xs btn-default" href="<?php echo e(URL::to('kajian/')); ?>" >Petinjau</a>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="<?php echo e(URL::to('admin/')); ?>">Beranda</a>
                    </li>
                    <li>
                        <i class="fa fa-play"></i>  <a href="<?php echo e(URL::to('admin-kajian-all/')); ?>">Kajian</a>
                    </li>
                    <li class="active">
                        Lihat Post
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-sm-9">
                
                    <br>
                
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                    <?php foreach($kajianShow as $index => $kajian): ?>
                    
                    <div class="form-group">
                        <label>Judul</label>
                        <p class="form-control-static"><?php echo e($kajian->judul); ?></p>
                    </div><hr>
                    
                    <div class="form-group">
                        <label>Upload Gambar</label>
                        <?php if($kajian->gambar != null): ?>
                        <img class="img-responsive" src="<?php echo e(url('foto/'.$kajian->gambar)); ?>" alt="">
                        <?php else: ?>
                        <p class="form-control-static"><i>Tidak ada gambar</i></p>
                        <?php endif; ?>
                    </div><hr>

                    <div class="form-group">
                        <label>Kalimat Ajakan</label>
                        <?php if($kajian->ajakan != null): ?>
                        <p class="form-control-static"><?php echo e($kajian->ajakan); ?></p>
                        <?php else: ?>
                        <p class="form-control-static"><i>Tidak ada</i></p>
                        <?php endif; ?>
                    </div><hr>

                    <div class="form-group">
                        <label>Isi</label>
                        <?php if($kajian->isi != null): ?>
                        <p class="form-control-static"><?php echo e($kajian->isi); ?></p>
                        <?php else: ?>
                        <p class="form-control-static"><i>Tidak ada</i></p>
                        <?php endif; ?>
                    </div><hr>
                
                    <div class="form-group">
                        <label>Link Audio</label>
                        <br>
                        <?php if($kajian->audio != null): ?>
                        <iframe class="embed-responsive-item" width="300" height="125" scrolling="no" frameborder="no"
                            src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/<?php echo e($kajian->audio); ?>&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false"></iframe>
                        <?php else: ?>
                        <p class="form-control-static"><i>Tidak ada audio</i></p>
                        <?php endif; ?>
                    </div><hr>
                    
                    <div class="form-group">
                        <label>Link Video</label>
                        <br>
                        <?php if($kajian->video != null): ?>
                        <iframe width="300" height="200" src="https://www.youtube.com/embed/<?php echo e($kajian->video); ?>" frameborder="0" allowfullscreen></iframe>
                        <?php else: ?>
                        <p class="form-control-static"><i>Tidak ada video</i></p>
                        <?php endif; ?>
                    </div><hr>

                    <fieldset disabled>
                    <div class="form-group">
                        <div class="row col-lg-12">
                            <label>Kategori</label>
                        </div>
                        <div class="row col-lg-2">
                            <div class="radio">
                                <label>
                                    <input type="radio" name="kategori" value="Tauhid" 
                                    <?php if($kajian->kategori == 'Tauhid'): ?> <?php echo e('checked'); ?>

                                    <?php endif; ?>
                                    >Tauhid
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="kategori" value="Fiqih"
                                    <?php if($kajian->kategori == 'Fiqih'): ?> <?php echo e('checked'); ?>

                                    <?php endif; ?>
                                    >Fiqih
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="kategori" value="Akhlak"
                                    <?php if($kajian->kategori == 'Akhlak'): ?> <?php echo e('checked'); ?>

                                    <?php endif; ?>
                                    >Akhlak
                                </label>
                            </div>
                        </div>
                        <div class="row col-lg-10">
                            <div class="radio">
                                <label>
                                    <input type="radio" name="kategori" value="Tafsir"
                                    <?php if($kajian->kategori == 'Tafsir'): ?> <?php echo e('checked'); ?>

                                    <?php endif; ?>
                                    >Tafsir
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="kategori" value="Sirah"
                                    <?php if($kajian->kategori == 'Sirah'): ?> <?php echo e('checked'); ?>

                                    <?php endif; ?>
                                    >Sirah
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="kategori" value="Tematik"
                                    <?php if($kajian->kategori == 'Tematik'): ?> <?php echo e('checked'); ?>

                                    <?php endif; ?>
                                    >Tematik
                                </label>
                            </div>
                        </div>
                    </div>
                    </fieldset>
                    
                    <br>

                    <a type="submit" class="btn btn-primary" href="<?php echo e(URL::to('admin-kajian-edit/'.$kajian->id_kajian)); ?>" > Edit</a>
                    <a type="submit" class="btn btn-danger" href="<?php echo e(URL::to('admin-kajian-delete/'.$kajian->id_kajian)); ?>" > Hapus</a>
                    <a type="submit" class="btn btn-warning" href="<?php echo e(URL::to('admin-kajian-all/')); ?>" > Keluar</a>
                    
                    <?php endforeach; ?>
                
            </div>

        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>