<?php $__env->startSection("content"); ?>

<!-- Kegiatan -->
<div class="container">

    <div class="row">
        <div class="col-sm-12">
            <h1 class="page-header">Berita
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(URL::to('')); ?>">Home</a>
                </li>
                <li class="active">Berita</li>
            </ol>
        </div>
    </div>
    <!-- /.row -->

    <i><strong>kata kunci: </strong></i>
    <?php if($beritaKunci[0] != null): ?>
    <?php foreach($beritaKunci as $index => $berita): ?>
    <!-- Kata Kunci -->
        <i><a href="<?php echo e(URL::to('berita/'.$berita->kunci)); ?>"><?php echo e($berita->kunci); ?></a>, </i>
    <?php endforeach; ?>

    <?php else: ?>
        <i>Tidak ditemukan kata kunci</i>
    <?php endif; ?>

    <br><br><br>

    <!-- Post Berita -->
    <div class="row">
        <div class="col-sm-12">
            <h2 class="page-header">Post Berita</h2>
        </div>
    </div>
    
    <br>
    
    <?php if($beritaAll[0] != null): ?>
    <?php foreach($beritaAll as $index => $berita): ?>
    
    <!-- Blog Post Row -->
    <div class="row">
        <div class="col-sm-6">
            <a href="<?php echo e(URL::to('berita/'.$berita->kunci.'/'.$berita->id_berita)); ?>">
                <img class="img-responsive img-hover post-image-small" style="background-image:url(<?php echo e(url('resource/berita.png')); ?>);" src="<?php echo e(url('foto/'.$berita->gambar)); ?>" alt="<?php echo e($berita->gambar); ?>">
            </a>
        </div>
        <div class="col-sm-6">
            <h3>
                <a href="<?php echo e(URL::to('berita/'.$berita->kunci.'/'.$berita->id_berita)); ?>"><?php echo substr(strip_tags($berita->judul), 0, 75) ?></a>
            </h3>
            <p><i><strong>kata kunci</strong> <a href="<?php echo e(URL::to('berita/'.$berita->kunci)); ?>"><?php echo e($berita->kunci); ?></a></i></p>
            <?php echo substr(strip_tags($berita->isi), 0, 350) ?><br>
            <a class="btn btn-primary" href="<?php echo e(URL::to('berita/'.$berita->kunci.'/'.$berita->id_berita)); ?>"><i class="fa fa-angle-right">Read More </i></a>
        </div>
    </div>
    <!-- /.row -->
    
    <hr>
    
    <?php endforeach; ?>
    
    <?php else: ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="alert alert-info" role="alert" align="center"><i>Hasil pencarian tidak ditemukan</i></div>
        </div>
    </div>
    <hr>
    <?php endif; ?>
    
    <strong>Jumlah berita: <?php echo e($jumlah); ?></strong>
    
    <div class="paging">
        <?php echo e($beritaAll->links()); ?>

    </div>
    
    <br><br><br><br>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>