<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Semua Post <small>Berita</small> <a type="button" class="btn btn-xs btn-default" href="<?php echo e(URL::to('berita/')); ?>">Petinjau</a>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="<?php echo e(URL::to('admin/')); ?>">Beranda</a>
                    </li>
                    <li>
                        <i class="fa fa-list"></i>  <a href="<?php echo e(URL::to('admin-berita-all/')); ?>">Berita</a>
                    </li>
                    <li class="active">
                        Semua Post
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-12">

                <?php if(Session::has('message')): ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <i class="fa fa-info-circle"></i>  <strong><?php echo e(Session::get('message')); ?></strong>
                </div>
                <?php endif; ?>

                <?php if(Session::has('destroy')): ?>
                <div class="alert alert-success alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <i class="fa fa-info-circle"></i>  <strong><?php echo e(Session::get('destroy')); ?></strong>
                </div>
                <?php endif; ?>

                <strong>Kata kunci: </strong>
                <?php if($beritaKunci[0] != null): ?>
                <?php foreach($beritaKunci as $index => $berita): ?>
                <!-- Kata Kunci -->
                    <i><a href="<?php echo e(URL::to('admin-berita-all/'.$berita->kunci)); ?>"><?php echo e($berita->kunci); ?></a>, </i>
                <?php endforeach; ?>

                <?php else: ?>
                    <i>Tidak ditemukan kata kunci</i>
                <?php endif; ?>
                
                <br><br>
                
<!--                <h3>Edit Post Berita</h3>-->
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                        <thead>
                            <tr>
                                <th>Tanggal Buat</th>
                                <th>Judul</th>
                                <th>Kata Kunci</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($beritaAll[0] != null): ?>
                                <?php foreach($beritaAll as $index => $berita): ?>
                                    <tr>
                                        <td><?php echo e($berita->created_at); ?></td>
                                        <td><?php echo substr(strip_tags($berita->judul), 0, 75) ?></td>
                                        <td><?php echo e($berita->kunci); ?></td>
                                        
                                        <td>
                                            <a type="submit" class="btn btn-sm btn-primary" href="<?php echo e(URL::to('admin-berita-view/'.$berita->id_berita)); ?>">Lihat</a>
                                            <a type="submit" class="btn btn-sm btn-warning" href="<?php echo e(URL::to('admin-berita-edit/'.$berita->id_berita)); ?>">Edit</a>
                                            <a type="submit" class="btn btn-sm btn-danger" href="<?php echo e(URL::to('admin-berita-delete/'.$berita->id_berita)); ?>"> Hapus</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" style="text-align: center"><i>Tidak Ada berita</i></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pager -->
                <div class="tabel-nav">
                    <div class="jumlah-data">
                        <strong> Jumlah berita: <?php echo e($jumlah); ?>

                        </strong>
                    </div>
                    <div class="paging">
                        <?php echo e($beritaAll->links()); ?>

                    </div>
                </div>
                <!-- /.row -->

                <br>
                
                <div>
                    <a type="submit" class="btn btn-primary" href="<?php echo e(URL::to('admin-berita-add/')); ?>" >Tambah Berita</a>
                </div>    
            
                <br><br><br><br>

            </div>

        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>