<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Semua Pesan <small>Buku Tamu</small> <button type="button" class="btn btn-xs btn-default">Petinjau</button>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="index.html">Home</a>
                    </li>
                    <li>
                        <i class="fa fa-envelope"></i>  <a href="index.html">Kotak Pesan </a>
                    </li>
                    <li class="active">
                        Semua Pesan
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-12">

<!--                <h3>Buku Tamu </h3> -->
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Waktu</th>
                                <th>Nama</th>
                                <th>Nomor</th>
                                <th>Email</th>
                                <th>Pesan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum</td>
                                <td>085743405202</td>
                                <td>dzulfikar.moeslem@gmail.com</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum</td>
                                <td>085743405202</td>
                                <td>dzulfikar.moeslem@gmail.com</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum</td>
                                <td>085743405202</td>
                                <td>dzulfikar.moeslem@gmail.com</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum</td>
                                <td>085743405202</td>
                                <td>dzulfikar.moeslem@gmail.com</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum</td>
                                <td>085743405202</td>
                                <td>dzulfikar.moeslem@gmail.com</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum</td>
                                <td>085743405202</td>
                                <td>dzulfikar.moeslem@gmail.com</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum</td>
                                <td>085743405202</td>
                                <td>dzulfikar.moeslem@gmail.com</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum</td>
                                <td>085743405202</td>
                                <td>dzulfikar.moeslem@gmail.com</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum</td>
                                <td>085743405202</td>
                                <td>dzulfikar.moeslem@gmail.com</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum</td>
                                <td>085743405202</td>
                                <td>dzulfikar.moeslem@gmail.com</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                            </tr>
                        </tbody>
                    </table>
                    <button type="button" class="btn btn-danger">Hapus Semua Pesan</button>
                </div>

                <!-- Pager -->
                <div class="row">
                    <ul class="pager">
                        <li class="previous"><a href="#">&larr; Newer</a>
                        </li>
                        <li class="next"><a href="#">Older &rarr;</a>
                        </li>
                    </ul>
                </div>
                <!-- /.row -->

                <hr>

                <br>

                <h3>Edit FAQ</h3>
                <br>

                <h4>- Baris 1</h4>
                <div class="form-group">
                    <label>Pertanyaan:</label>
                    <input class="form-control">
                </div>

                <div class="form-group">
                    <label>Jawaban:</label>
                    <textarea class="form-control" rows="3"></textarea>
                </div>

                <hr>

                <h4>- Baris 2</h4>
                <div class="form-group">
                    <label>Pertanyaan:</label>
                    <input class="form-control">
                </div>

                <div class="form-group">
                    <label>Jawaban:</label>
                    <textarea class="form-control" rows="3"></textarea>
                </div>

                <hr>

                <h4>- Baris 3</h4>
                <div class="form-group">
                    <label>Pertanyaan:</label>
                    <input class="form-control">
                </div>

                <div class="form-group">
                    <label>Jawaban:</label>
                    <textarea class="form-control" rows="3"></textarea>
                </div>

                <hr>

                <h4>- Baris 4</h4>
                <div class="form-group">
                    <label>Pertanyaan:</label>
                    <input class="form-control">
                </div>

                <div class="form-group">
                    <label>Jawaban:</label>
                    <textarea class="form-control" rows="3"></textarea>
                </div>

                <hr>

                <h4>- Baris 5</h4>
                <div class="form-group">
                    <label>Pertanyaan:</label>
                    <input class="form-control">
                </div>

                <div class="form-group">
                    <label>Jawaban:</label>
                    <textarea class="form-control" rows="3"></textarea>
                </div>

                <button type="button" class="btn btn-primary">Simpan FAQ</button>

            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>