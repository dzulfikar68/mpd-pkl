<?php $__env->startSection("content"); ?>

<div class="container">
    <p></p>
    <div class="panel panel-default">
        Login
    </div>
    <div class="panel-body">
        <?php echo e(Form::open(['url' => '/login'])); ?>

        Username:
        <br/>
        <p></p>
        <?php echo e(Form::text('username', '', ['placeholder' => 'Username','class' => 'form-control'])); ?>

        Password:
        <br/>
        <p></p>
        <?php echo e(Form::password('password', array('class' => 'form-control','placeholder' => 'Password'))); ?>

        <p></p>
        <?php echo e(Form::submit('Login', ['class' => 'btn btn-danger'])); ?>

        <?php echo e(Form::close()); ?>


    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>