<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Tambah Post <small>Berita</small> <button type="button" class="btn btn-xs btn-default">Petinjau</button>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="#">Beranda</a>
                    </li>
                    <li>
                        <i class="fa fa-list"></i>  <a href="#">Berita</a>
                    </li>
                    <li class="active">
                        Tambah Post
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-8">

                <form role="form">

                    <br>
                    
<!--                    <h3>Tambah Post Berita</h3>-->

                    <div class="form-group">
                        <label>Judul</label>
                        <input class="form-control" placeholder="masukkan judul">
                    </div>

                    <div class="form-group">
                        <label>Upload Gambar</label>
                        <input type="file">
                    </div>

                    <div class="form-group">
                        <label>Link Audio</label>
                        <input class="form-control" placeholder="masukkan tautan soundcloud">
                    </div>

                    <div class="form-group">
                        <label>Link Video</label>
                        <input class="form-control" placeholder="masukkan tautan youtube">
                    </div>

                    <div class="form-group">
                        <label>Kalimat Ajakan</label>
                        <textarea class="form-control" rows="3"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Isi</label>
                        <textarea class="form-control" rows="3"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Kata Kunci</label>
                        <input class="form-control" placeholder="masukkan kata kunci">
                    </div>

                    <button type="submit" class="btn btn-primary">Simpan</button>

                </form>

            </div>

        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>