<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    FAQ <button type="button" class="btn btn-xs btn-default" href="<?php echo e(URL::to('faq/')); ?>">Petinjau</button>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="<?php echo e(URL::to('admin/')); ?>">Beranda </a>
                    </li>
                    <li class="active">
                        <i class="fa fa-comment"></i>
                        FAQ
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-md-9">
                
                <h3>Tambah FAQ</h3>
                
                <?php if(Session::has('message')): ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <i class="fa fa-info-circle"></i>  <strong><?php echo e(Session::get('message')); ?></strong>
                </div>
                <?php endif; ?>

                <?php if(Session::has('destroy')): ?>
                <div class="alert alert-success alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <i class="fa fa-info-circle"></i>  <strong><?php echo e(Session::get('destroy')); ?></strong>
                </div>
                <?php endif; ?>
                
                <form role="form" method="post" action="<?php echo e(action('admin\FaqController@store')); ?>">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <br>

                    <div class="form-group">
                        <label>Pertanyaan</label>
                        <input class="form-control" name="q">
                    </div>

                    <div class="form-group">
                        <label>Jawaban</label>
                        <textarea class="form-control" rows="3" name="a"></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">Simpan</button>
                
                </form>

            </div>

            <div class="col-md-12">

            <hr>
                
                <h3>View FAQ</h3>
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Pertanyaan</th>
                                <th>Jawaban</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if($faqAll[0] != null): ?>
                            <?php foreach($faqAll as $index => $faq): ?>
                            <tr>
                                <td><?php echo e($index+1); ?></td>
                                <td><?php echo e($faq->q); ?></td>
                                <td><?php echo e($faq->a); ?></td>
                                <td>
                                    <a type="submit" class="btn btn-sm btn-danger" href="<?php echo e(URL::to('admin-faq-delete/'.$faq->id_faq)); ?>">Hapus</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" style="text-align: center"><i>Tidak Ada Faq</i></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>