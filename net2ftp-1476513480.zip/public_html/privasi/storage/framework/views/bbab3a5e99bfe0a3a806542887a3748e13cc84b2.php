<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Beranda
                </h1>
                <ol class="breadcrumb">
                    <li class="active">
                        <i class="fa fa-dashboard"></i> Beranda
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-12">

                <?php if(Session::has('message')): ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <i class="fa fa-info-circle"></i>  <strong><?php echo e(Session::get('message')); ?></strong>
                </div>
                <?php endif; ?>
                
                <div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <i class="fa fa-info-circle"></i>  <strong>Selamat Datang di Admin MPD (Masjid Pangeran Diponegoro)</strong>, silahkan klik: <a href="<?php echo e(URL::to('')); ?>" class="alert-link">Website MPD</a>
                </div>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">

            <!-- PESAN -->
            <div class="col-lg-4 col-md-6">
                <div class="panel panel-red">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-envelope fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo e($pesanAll); ?></div>
                                <div>Jumlah Pesan Masuk</div>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(URL::to('admin-pesan-all/')); ?>">
                        <div class="panel-footer">
                            <span class="pull-left">Lihat Detail</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>


            <!-- KAJIAN -->
            <div class="col-lg-4 col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-book fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo e($kajianAll); ?></div>
                                <div>Total Post Kajian</div>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(URL::to('admin-kajian-all/')); ?>">
                        <div class="panel-footer">
                            <span class="pull-left">Lihat Detail</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>

            <!-- DONASI -->
            <div class="col-lg-4 col-md-6">
                <div class="panel panel-green">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-support fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo e($saldo->masuk - $saldo->keluar); ?></div>
                                <div>Saldo Donasi Terkini</div>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(URL::to('admin-donasi-all/')); ?>">
                        <div class="panel-footer">
                            <span class="pull-left">Lihat Detail</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            
            <div class="col-lg-4">
                <div class="panel panel-red">
                    <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-comment fa-fw"></i> Pesan Masuk</h3>
                    </div>
                    <div class="panel-body">
                        <div class="list-group">
                        <?php if($pesan[0] != null): ?>
                        <?php foreach($pesan as $index => $pes): ?>
                            <a href="#" class="list-group-item">
                                <span class="badge"><?php echo substr(strip_tags($pes->nama), 0, 10) ?></span>
                                <i class="fa fa-fw fa-user"></i> <?php echo substr(strip_tags($pes->isi), 0, 20) ?>...
                            </a>
                        <?php endforeach; ?>
                        <?php else: ?>
                            <a href="<?php echo e(URL::to('admin-pesan-all/')); ?>" class="list-group-item">
                                <i>tidak ada pesan</i>
                            </a>
                        <?php endif; ?>
                        </div>
                        <div class="text-right">
                            <a href="<?php echo e(URL::to('admin-pesan-all/')); ?>">Lihat Detail <i class="fa fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-th fa-fw"></i> Persentase Kajian</h3>
                    </div>
                    <div class="panel-body">
                        <canvas id="canvas" height="262">
                            No Love for HTML5 eh?
                        </canvas>
                        <div class="text-right">
                            <a href="<?php echo e(URL::to('admin-kajian-all/')); ?>">Lihat Detail <i class="fa fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="panel panel-green">
                    <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-money fa-fw"></i> Pemasukan Donasi</h3>
                    </div>
                    <div class="panel-body" style="margin-bottom: 25px">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Laporan Bulanan</th>
                                        <th>Saldo</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php if($donasi[0] != null): ?>
                                <?php foreach($donasi as $index => $don): ?>
                                    <tr>
                                        <td><?php echo e($don->tanggal); ?></td>
                                        <td><?php echo e($don->masuk - $don->keluar); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="2" style="text-align: center"><i>tidak ada donasi</i></td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-right">
                            <a href="<?php echo e(URL::to('admin-donasi-all/')); ?>">Lihat Detail <i class="fa fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->

       <!--  <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-bar-chart-o fa-fw"></i> Grafik Postingan Kajian</h3>
                    </div>
                    <div class="panel-body">
                        <div id="morris-area-chart"></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>