<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Berita <button type="button" class="btn btn-xs btn-default">Petinjau</button>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="index.html">Home</a>
                    </li>
                    <li class="active">
                        Berita
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-10">

                <form role="form">

                    <h3>Tambah Post Berita</h3>

                    <div class="form-group">
                        <label>Judul</label>
                        <input class="form-control" placeholder="masukkan judul">
                    </div>

                    <div class="form-group">
                        <label>Upload Gambar</label>
                        <input type="file">
                    </div>

                    <div class="form-group">
                        <label>Link Audio</label>
                        <input class="form-control" placeholder="masukkan tautan soundcloud">
                    </div>

                    <div class="form-group">
                        <label>Link Video</label>
                        <input class="form-control" placeholder="masukkan tautan youtube">
                    </div>

                    <div class="form-group">
                        <label>Kalimat Ajakan</label>
                        <textarea class="form-control" rows="3"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Isi</label>
                        <textarea class="form-control" rows="3"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Kata Kunci</label>
                        <input class="form-control" placeholder="masukkan kata kunci">
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>

                </form>

                <hr>

                <br>

                <h3>Edit Post Berita</h3>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Waktu</th>
                                <th>Judul</th>
                                <th>Kata Kunci</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>idul adha</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>idul adha</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>idul fitri</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>idul fitri</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>ramadhan</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>syawal</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>pesantren programmer</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>idul adha</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>idul adha</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>idul fitri</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Pager -->
                <div class="row">
                    <ul class="pager">
                        <li class="previous"><a href="#">&larr; Newer</a>
                        </li>
                        <li class="next"><a href="#">Older &rarr;</a>
                        </li>
                    </ul>
                </div>
                <!-- /.row -->

            </div>

        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>