<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Balas Pesan <small>Buku Tamu</small> <button type="button" class="btn btn-xs btn-default" href="<?php echo e(URL::to('profil/')); ?>">Petinjau</button>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="<?php echo e(URL::to('admin/')); ?>">Beranda</a>
                    </li>
                    <li>
                        <i class="fa fa-envelope"></i>  <a href="<?php echo e(URL::to('admin-pesan-all/')); ?>">Buku Tamu </a>
                    </li>
                    <li class="active">
                        Balas Pesan
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-9">

                <br>
                
        <!-- PAKAI MODAL (KALAU BISA)-->
                
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                
                <?php foreach($pesanShow as $index => $pesan): ?>
                <div class="form-group">
                    <label>Tanggal Masuk:</label>
                    <p class="form-control-static"><?php echo e($pesan->created_at); ?></p>
                </div><hr>
                <div class="form-group">
                    <label>Nama Lengkap:</label>
                    <p class="form-control-static"><?php echo e($pesan->nama); ?></p>
                </div><hr>
                <div class="form-group">
                    <label>Nomor Telepon:</label>
                    <p class="form-control-static"><?php echo e($pesan->nope); ?></p>
                </div><hr>
                <div class="form-group">
                    <label>Alamat Email:</label>
                    <p class="form-control-static"><?php echo e($pesan->email); ?></p>
                </div><hr>
                <div class="form-group">
                    <label>Pesan:</label>
                    <p class="form-control-static"><?php echo e($pesan->isi); ?></p>
                </div>

                <br>

                <a type="submit" class="btn btn-primary" href="mailto:<?php echo e($pesan->email); ?>?subject=[Balasan] untuk Pesan: <?php echo e($pesan->isi); ?>

                &body=Hai <?php echo e($pesan->nama); ?>, Terima Kasih sudah mengirimkan Pesan ke MPD">Kirim</a>

                <a type="submit" class="btn btn-warning" href="<?php echo e(URL::to('admin-pesan-all')); ?>">Keluar</a>

                <a type="submit" class="btn btn-danger" href="<?php echo e(URL::to('admin-pesan-delete/'.$pesan->id_pesan)); ?>">Hapus</a>

                <?php endforeach; ?>

            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>