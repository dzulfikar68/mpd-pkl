<?php $__env->startSection("content"); ?>

<div class="container">
    <p></p>
    <div class="panel panel-default">
        <h3 align="center">Login</h3>
        <br>
    </div>

    <div class="col-md-4"></div>
    <div class="panel-body col-md-4">
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-info" align="center">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <i class="fa fa-info-circle"></i>  <strong><?php echo e(Session::get('message')); ?></strong>
        </div>
        <?php endif; ?>
        <form role="form" method="post" action="<?php echo e(action('LoginController@login')); ?>">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="form-group">
                <label>Username</label>
                <input class="form-control" placeholder="masukkan username" name="username">
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" placeholder="masukkan password" name="password">
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>