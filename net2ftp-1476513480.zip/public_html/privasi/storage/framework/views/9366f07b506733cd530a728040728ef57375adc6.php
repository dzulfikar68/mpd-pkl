<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Semua Post <small>Mahad Al Madinah</small> <button type="button" class="btn btn-xs btn-default">Petinjau</button>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="#">Beranda</a>
                    </li>
                    <li>
                        <i class="fa fa-edit"></i>  <a href="#">Mahad</a>
                    </li>
                    <li class="active">
                        Semua Post
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-10">
                
                <br>

<!--                <h3>Edit Post Mahad</h3>-->
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Judul</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>..</td>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>..</td>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>..</td>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>..</td>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>..</td>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>..</td>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>..</td>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>..</td>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>..</td>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>..</td>
                                <td>8/1/1995</td>
                                <td>lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary">Edit</button>
                                    <button type="button" class="btn btn-sm btn-red">Hapus</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Pager -->
                <div class="row">
                    <ul class="pager">
                        <li class="previous"><a href="#">&larr; Newer</a>
                        </li>
                        <li class="next"><a href="#">Older &rarr;</a>
                        </li>
                    </ul>
                </div>
                <!-- /.row -->

            </div>

        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>