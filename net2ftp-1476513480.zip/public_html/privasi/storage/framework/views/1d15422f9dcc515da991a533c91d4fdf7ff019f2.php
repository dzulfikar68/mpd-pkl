<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Edit Post <small>Berita</small> <a type="button" class="btn btn-xs btn-default" href="<?php echo e(URL::to('kajian/')); ?>">Petinjau</a>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="<?php echo e(URL::to('admin/')); ?>">Beranda</a>
                    </li>
                    <li>
                        <i class="fa fa-list"></i>  <a href="<?php echo e(URL::to('admin-berita-all/')); ?>">Berita</a>
                    </li>
                    <li class="active">
                        Edit Post
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-8">

                <form role="form" method="post" action="<?php echo e(action('admin\BeritaController@update', [$berita->id_berita])); ?>">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                    <br>

                    <div class="form-group">
                        <label>Judul</label>
                        <input class="form-control" placeholder="masukkan judul {wajib}" name="judul" value="<?php echo e($berita->judul); ?>">
                    </div>
                    
                    <fieldset disabled>
                        <div class="form-group">
                            <label>Upload Gambar</label>
                            <input type="file" name="gambar" value="<?php echo e($berita->gambar); ?>">
                        </div>
                    </fieldset>

                    <div class="form-group">
                        <label>Kalimat Ajakan</label>
                        <textarea class="form-control" rows="3" name="ajakan" ><?php echo e($berita->ajakan); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label>Isi</label>
                        <textarea class="form-control" rows="28" name="isi" ><?php echo e($berita->isi); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label>Link Audio</label>
                        <?php if($berita->audio != null): ?>
                        <input class="form-control" placeholder="masukkan tautan embed soundcloud" name="audio" value="<?php echo e($berita->audio); ?>">
                        <br>
                        <iframe class="embed-responsive-item" width="400" height="125" scrolling="no" frameborder="no"
                            src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/<?php echo e($berita->audio); ?>&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false"></iframe>
                        <?php else: ?>
                        <input class="form-control" placeholder="masukkan tautan embed soundcloud" name="audio" value="<?php echo e($berita->audio); ?>">
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Link Video</label>
                        <?php if($berita->video != null): ?>
                        <input class="form-control" placeholder="masukkan tautan embed youtube" name="video" value="<?php echo e($berita->video); ?>">
                        <br>
                        <iframe width="400" height="250" src="https://www.youtube.com/embed/<?php echo e($berita->video); ?>" frameborder="0" allowfullscreen></iframe>
                        <?php else: ?>
                        <input class="form-control" placeholder="masukkan tautan embed youtube" name="video" value="<?php echo e($berita->video); ?>">
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Kata Kunci</label>
                        <input class="form-control" placeholder="masukkan kata kunci" name="kunci" value="<?php echo e($berita->kunci); ?>">

                    </div>
                    
                    <br>

                    <button type="submit" class="btn btn-primary">Simpan</button>

                </form>

            </div>

        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>