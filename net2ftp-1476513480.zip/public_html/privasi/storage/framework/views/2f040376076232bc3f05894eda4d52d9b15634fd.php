<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Donasi <button type="button" class="btn btn-xs btn-default">Petinjau</button>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="#">Beranda</a>
                    </li>
                    <li class="active">
                        <i class="fa fa-file"></i>
                        Donasi
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-8">

                <br>

                <p class="lead">Pemasukan</p>
                <form role="form">
                    <div class="form-group">
                        <label>Upload File Excel</label>
                        <input type="file">
                    </div>
                </form>

                <br>

                <p class="lead">Pengeluaran</p>
                <form role="form">
                    <div class="form-group">
                        <label>Upload File Excel</label>
                        <input type="file">
                    </div>
                </form>

                <button type="submit" class="btn btn-primary">Simpan</button>
                <button type="submit" class="btn btn-primary">Lihat</button>
                
                <hr>
                <br>
                
                <p class="lead">Total Saldo Terkini</p>
                <p>Pemasukan (Rp) - Pengeluaran (Rp) = Rp...</p>

            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>