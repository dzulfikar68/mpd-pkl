<?php $__env->startSection("content"); ?>

<!-- Kegiatan -->
<div class="container">

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Khotbah Jum'at
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(URL::to('')); ?>">Home</a>
                </li>
                <li><a href="<?php echo e(URL::to('kegiatan/')); ?>">Kegiatan</a>
                </li>
                <li class="active">Khotbah</li>
            </ol>
        </div>
    </div>
    <!-- /.row -->

    <!-- Content Row -->
    <div class="row">

        <!-- Blog Post Content Column -->
        <div class="col-lg-8">

            <!-- Blog Post -->
            <hr>

            <!-- Preview Image -->
            <!-- thanks for: sekolahkoding.com -->
            <img class="img-responsive post-image" id="img-post" src="<?php echo e(url('resource/khotbah.png')); ?>" alt="Default">

            <hr>

            <p class="lead" align="center">
                بِسْــــــــــــــــــمِ اللهِ الرَّحْمَنِ الرَّحِيْمِ
                <br>
                <!-- Cari Hadist di Google -->
            </p>

            <hr>
            <p></p>
            <?php foreach($khotbah as $index => $khot): ?>
                <iframe src="<?php echo e(url('pdf/'.$khot->pdf)); ?>" width="100%" height="1000">
                    <a href="<?php echo e(url('pdf/'.$khot->pdf)); ?>">Download PDF</a>
                </iframe>
            <?php endforeach; ?>
            
            <hr>
            
            <!-- Comments Form -->

            <div class="fb-comments" data-href="https://www.facebook.com/MuslimUndip" data-width="100%" data-numposts="5"></div>

            <!------------------->

        </div>

        <!-- Blog Sidebar Widgets Column -->
        <div class="col-md-4">

            <!-- Blog Categories Well -->
            <div class="well">
                <h4>Kategori Kegiatan</h4>
                <div class="row">
                    <div class="col-lg-6">
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(URL::to('khotbah/')); ?>">Khotbah Jumat</a>
                            </li>
                            <li><a href="<?php echo e(URL::to('kajian/')); ?>">Kajian Rutin</a>
                            </li>
                            <li><a href="<?php echo e(URL::to('mahad/')); ?>">Mahad Al Madinah</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- /.row -->
            </div>

            <!-- Blog Categories Well -->
            <div class="well">
                <h4>Kategori Kajian</h4>
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(URL::to('kajian/Tauhid')); ?>">Tauhid/ Akidah</a>
                            </li>
                            <li><a href="<?php echo e(URL::to('kajian/Fiqih')); ?>">Fiqih/ Ibadah</a>
                            </li>
                            <li><a href="<?php echo e(URL::to('kajian/Akhlak')); ?>">Akhlak/ Adab</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(URL::to('kajian/Tafsir')); ?>">Tafsir/ Kitab</a>
                            </li>
                            <li><a href="<?php echo e(URL::to('kajian/Sirah')); ?>">Sirah/ Sejarah</a>
                            </li>
                            <li><a href="<?php echo e(URL::to('kajian/Tematik')); ?>">Tematik/ Umum</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- /.row -->
            </div>

            <!-- Side Widget Well -->
            <div class="well">
                <h4>Kata Kunci Berita</h4>
                <?php if($beritaKunci[0] != null): ?>
                <?php foreach($beritaKunci as $index => $berita): ?>
                <!-- Kata Kunci -->
                    <i><a href="<?php echo e(URL::to('berita/'.$berita->kunci)); ?>"><?php echo e($berita->kunci); ?></a>, </i>
                <?php endforeach; ?>

                <?php else: ?>
                    <i>Tidak ditemukan kata kunci</i>
                <?php endif; ?>
                <br><br>
            </div>

        </div>

    </div>
    <!-- /.row -->

    <?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>