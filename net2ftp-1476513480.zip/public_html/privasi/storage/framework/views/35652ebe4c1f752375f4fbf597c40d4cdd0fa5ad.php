
<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>(admin) Masjid Pangeran Diponegoro</title>

        <!-- Bootstrap Core CSS -->
        <link href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="<?php echo e(url('assets/css/sb-admin.css')); ?>" rel="stylesheet">

        <link rel="stylesheet" href="<?php echo e(url('assets/cleditor/jquery.cleditor.css')); ?>" />

        <!-- Custom Fonts -->
        <link href="<?php echo e(url('assets/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->


    </head>

    <body>

        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="admin">Admin MPD Semarang</a>
                </div>
                <!-- Top Menu Items -->
                <ul class="nav navbar-right top-nav">
                    <li>
                        <a href="<?php echo e(URL::to('')); ?>">Lihat Web</a>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> User <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="<?php echo e(URL::to('https://www.facebook.com/DIPOMUDA-623890651040050/')); ?>"><i class="fa fa-fw fa-user"></i> Profil FB</a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="<?php echo e(action('LoginController@logout')); ?>"><i class="fa fa-fw fa-power-off"></i> Logout</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
                <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav side-nav">
                        <li class="menu">
                            <a href="admin-pesan-all"><i class="fa fa-fw fa-envelope"></i> Pesan Masuk</a>
                        </li>
                        <li class="menu">
                            <a href="admin-khotbah"><i class="fa fa-fw fa-bullhorn"></i> Khotbah Jum'at </a>
                        </li>
                        <li class="menu">
                            <a href="javascript:;" data-toggle="collapse" data-target="#kajian"><i class="fa fa-fw fa-play"></i> Kajian Rutin <i class="fa fa-fw fa-caret-down"></i></a>
                            <ul id="kajian" class="collapse">
                                <li>
                                    <a href="<?php echo e(action('admin\KajianController@index')); ?>">Semua Kajian</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(action('admin\KajianController@create')); ?>">Tambah Kajian</a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu">
                            <a href="javascript:;" data-toggle="collapse" data-target="#mahad"><i class="fa fa-fw fa-book"></i> Mahad Al Madinah <i class="fa fa-fw fa-caret-down"></i></a>
                            <ul id="mahad" class="collapse">
                                <li>
                                    <a href="admin-mahad-all">Semua Post</a>
                                </li>
                                <li>
                                    <a href="admin-mahad-add">Tambah Post</a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu">
                            <a href="javascript:;" data-toggle="collapse" data-target="#berita"><i class="fa fa-fw fa-list"></i> Berita <i class="fa fa-fw fa-caret-down"></i></a>
                            <ul id="berita" class="collapse">
                                <li>
                                    <a href="admin-berita-all">Semua Berita</a>
                                </li>
                                <li>
                                    <a href="admin-berita-add">Tambah Berita</a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu">
                            <a href="javascript:;" data-toggle="collapse" data-target="#galeri"><i class="fa fa-fw fa-camera"></i> Galeri <i class="fa fa-fw fa-caret-down"></i></a>
                            <ul id="galeri" class="collapse">
                                <li>
                                    <a href="admin-galeri-all">Semua Foto</a>
                                </li>
                                <li>
                                    <a href="admin-galeri-add">Tambah Foto</a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu">
                            <a href="javascript:;" data-toggle="collapse" data-target="#donasi"><i class="fa fa-fw fa-file"></i> Donasi <i class="fa fa-fw fa-caret-down"></i></a>
                            <ul id="donasi" class="collapse">
                                <li>
                                    <a href="admin-donasi-all">Semua Laporan</a>
                                </li>
                                <li>
                                    <a href="admin-donasi-adds">Tambah Laporan</a>
                                </li>
                                <li>
                                    <a href="admin-donasi-addx">Detail Laporan</a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu">
                            <a href="admin-faq"><i class="fa fa-fw fa-comment"></i> FAQ </a>
                        </li>
                        <li class="menu">
                            <a href="admin-unduhan"><i class="fa fa-fw fa-download"></i> Unduhan </a>
                        </li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </nav>

            <?php echo $__env->yieldContent("content"); ?>


        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="<?php echo e(url('assets/js/jquery.js')); ?>"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>"></script>

        <script src="<?php echo e(url('assets/cleditor/jquery.cleditor.min.js')); ?>"></script>
        <script>
            $(document).ready(function () { $("#form_isi").cleditor(); });
        </script>

        <!-- Morris Charts JavaScript -->
       
        <script type="text/javascript">
            /* Collapse filter when another filter clicked*/
           $('.menu').click(function(){
               $('.menu .collapse.in').collapse('hide');
           });
        </script>

    </body>

</html>