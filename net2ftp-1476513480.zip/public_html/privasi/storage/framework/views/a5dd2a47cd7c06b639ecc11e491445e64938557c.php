<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Lihat Post <small>Mahad</small> <a type="submit" class="btn btn-xs btn-default" href="<?php echo e(URL::to('mahad/')); ?>" >Petinjau</a>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="<?php echo e(URL::to('admin/')); ?>">Beranda</a>
                    </li>
                    <li>
                        <i class="fa fa-play"></i>  <a href="<?php echo e(URL::to('admin-mahad-all/')); ?>">Mahad</a>
                    </li>
                    <li class="active">
                        Edit Post
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-8">
                
                    <br>
                
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                    <?php foreach($mahadShow as $index => $mahad): ?>
                    
                    <div class="form-group">
                        <label>Judul</label>
                        <p class="form-control-static"><?php echo e($mahad->judul); ?></p>
                    </div><hr>
                    
                    <div class="form-group">
                        <label>Upload Gambar</label>
                        <?php if($mahad->gambar != null): ?>
                        <img class="img-responsive" src="<?php echo e(url('foto/'.$mahad->gambar)); ?>" alt="">
                        <?php else: ?>
                        <p class="form-control-static"><i>Tidak ada gambar</i></p>
                        <?php endif; ?>
                    </div><hr>

                    <div class="form-group">
                        <label>Kalimat Ajakan</label>
                        <?php if($mahad->ajakan != null): ?>
                        <p class="form-control-static"><?php echo e($mahad->ajakan); ?></p>
                        <?php else: ?>
                        <p class="form-control-static"><i>Tidak ada</i></p>
                        <?php endif; ?>
                    </div><hr>

                    <div class="form-group">
                        <label>Isi</label>
                        <?php if($mahad->isi != null): ?>
                        <p class="form-control-static"><?php echo e($mahad->isi); ?></p>
                        <?php else: ?>
                        <p class="form-control-static"><i>Tidak ada</i></p>
                        <?php endif; ?>
                    </div><hr>
                
                    <div class="form-group">
                        <label>Link Audio</label>
                        <br>
                        <?php if($mahad->audio != null): ?>
                        <iframe class="embed-responsive-item" width="300" height="125" scrolling="no" frameborder="no"
                            src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/<?php echo e($mahad->audio); ?>&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false"></iframe>
                        <?php else: ?>
                        <p class="form-control-static"><i>Tidak ada audio</i></p>
                        <?php endif; ?>
                    </div><hr>
                    
                    <div class="form-group">
                        <label>Link Video</label>
                        <br>
                        <?php if($mahad->video != null): ?>
                        <iframe width="300" height="200" src="https://www.youtube.com/embed/<?php echo e($mahad->video); ?>" frameborder="0" allowfullscreen></iframe>
                        <?php else: ?>
                        <p class="form-control-static"><i>Tidak ada video</i></p>
                        <?php endif; ?>
                    </div><hr>
                    
                    <br>

                    <a type="submit" class="btn btn-primary" href="<?php echo e(URL::to('admin-mahad-edit/'.$mahad->id_mahad)); ?>" > Edit</a>
                    <a type="submit" class="btn btn-danger" href="<?php echo e(URL::to('admin-mahad-delete/'.$mahad->id_mahad)); ?>" > Hapus</a>
                    <a type="submit" class="btn btn-warning" href="<?php echo e(URL::to('admin-mahad-all/')); ?>" > Keluar</a>
                    
                    <?php endforeach; ?>
                
            </div>

        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>