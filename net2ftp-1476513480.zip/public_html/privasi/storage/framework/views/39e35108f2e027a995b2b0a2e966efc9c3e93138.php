<?php $__env->startSection("content"); ?>

<!-- Kegiatan -->
<div class="container">
    <?php foreach($mahadShow as $index => $mahad): ?>

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"><?php echo e($mahad->judul); ?>

            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(URL::to('/')); ?>">Home</a>
                </li>
                <li><a href="<?php echo e(URL::to('kegiatan/')); ?>">Kegiatan</a>
                </li>
                <li class="active">Mahad</li>
            </ol>
        </div>
    </div>
    <!-- /.row -->

    <!-- Content Row -->
    <div class="row">

        <!-- Blog Post Content Column -->
        <div class="col-lg-8">

            <!-- Blog Post -->
            <hr>

            Date/Time 
            <p><i class="fa fa-clock-o"></i> <?php echo e($mahad->created_at); ?></p>

            <hr>

            <!-- Preview Image -->
            <!-- thanks for: sekolahkoding.com -->
            <?php if($mahad->gambar != null): ?>
            <img class="img-responsive post-image" id="img-post" src="<?php echo e(url('foto/'.$mahad->gambar)); ?>" alt="$mahad->gambar">
            <?php else: ?>
            <img class="img-responsive post-image" id="img-post" src="<?php echo e(url('resource/mahad.png')); ?>" alt="Default">
            <?php endif; ?>

            <hr>

            <!-- Bagian Ajakan -->
            <?php if($mahad->ajakan != null): ?>
            <p class="lead" align="center">
                بِسْــــــــــــــــــمِ اللهِ الرَّحْمَنِ الرَّحِيْمِ
                <br>
                <?php echo e($mahad->ajakan); ?>

            </p>

            <!-- Bagian Isi -->
            <p><?php echo $mahad->isi; ?></p>
            <?php else: ?>
            <p class="lead" align="center">
                بِسْــــــــــــــــــمِ اللهِ الرَّحْمَنِ الرَّحِيْمِ
            </p>

            <p><?php echo $mahad->isi; ?></p>
            <?php endif; ?>

            <hr>
            
            <!-- Preview Audio -->
            <?php if($mahad->audio != null): ?>
            <div>
                <iframe class="embed-responsive-item" width="750" height="125" scrolling="no" frameborder="no"
                    src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/<?php echo e($mahad->audio); ?>&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false"></iframe>
            </div>
            <?php else: ?>
            <div class="alert alert-info" role="alert" align="center"><i>Tidak ada audio</i></div>
            <?php endif; ?>
            
            <hr>
            
            <!-- Preview Video -->
            <?php if($mahad->video != null): ?>
            <div class="embed-responsive embed-responsive-16by9">
                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo e($mahad->video); ?>" frameborder="0" allowfullscreen></iframe>
            </div>
            <?php else: ?>
            <div class="alert alert-info" role="alert" align="center"><i>Tidak ada video</i></div>
            <?php endif; ?>
            
            <hr>
            
            <!-- Blog Comments -->
            
            <?php endforeach; ?>

            <!-- Comments Form -->

            <div class="fb-comments" data-href="https://www.facebook.com/MuslimUndip" data-width="100%" data-numposts="5"></div>

            <!------------------->

        </div>

        <!-- Blog Sidebar Widgets Column -->
        <div class="col-md-4">

            <!-- Blog Search Well -->
            <div class="well">
                <h4>Cari Post</h4>
                <form role="form" method="get" action="<?php echo e(action('MahadController@cari')); ?>">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="input-group">
                        <input type="text" class="form-control" name="cari">
                        <span class="input-group-btn">
                            <button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
                        </span>
                    </div>
                </form>
                <!-- /.input-group -->
            </div>

            <!-- Blog Categories Well -->
            <div class="well">
                <h4>Kategori Kegiatan</h4>
                <div class="row">
                    <div class="col-lg-6">
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(URL::to('khotbah/')); ?>">Khotbah Jumat</a>
                            </li>
                            <li><a href="<?php echo e(URL::to('kajian/')); ?>">Kajian Rutin</a>
                            </li>
                            <li><a href="<?php echo e(URL::to('mahad/')); ?>">Mahad Al Madinah</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- /.row -->
            </div>

            <!-- Blog Categories Well -->
            <div class="well">
                <h4>Kategori Kajian</h4>
                <div class="row">
                    <div class="col-lg-6">
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(URL::to('kajian/Tauhid')); ?>">Tauhid/ Akidah</a>
                            </li>
                            <li><a href="<?php echo e(URL::to('kajian/Fiqih')); ?>">Fiqih/ Ibadah</a>
                            </li>
                            <li><a href="<?php echo e(URL::to('kajian/Akhlak')); ?>">Akhlak/ Adab</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-6">
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(URL::to('kajian/Tafsir')); ?>">Tafsir/ Kitab</a>
                            </li>
                            <li><a href="<?php echo e(URL::to('kajian/Sirah')); ?>">Sirah/ Sejarah</a>
                            </li>
                            <li><a href="<?php echo e(URL::to('kajian/Tematik')); ?>">Tematik/ Umum</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- /.row -->
            </div>

            <!-- Side Widget Well -->
            <div class="well">
                <h4>Post Mahad Terkait</h4>
                <div class="row">
                    <div class="col-lg-6">
                        <ul class="list-unstyled">
                            <?php foreach($mahadKait as $index => $kait): ?>
                            <li><a href="<?php echo e(URL::to('mahad/'.$kait->id_mahad)); ?>"><?php echo substr(strip_tags($kait->judul), 0, 40) ?></a>,
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                <!-- /.row -->
            </div>

        </div>

    </div>
    <!-- /.row -->

    <?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>