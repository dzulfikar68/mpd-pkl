<?php $__env->startSection("content"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-sm-12">
                <h1 class="page-header">
                    Semua Foto <small>Galeri</small> <a type="button" class="btn btn-xs btn-default" href="<?php echo e(URL::to('galerifoto/')); ?>">Petinjau</a>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="<?php echo e(URL::to('admin/')); ?>">Beranda</a>
                    </li>
                    <li>
                        <i class="fa fa-camera"></i>  <a href="<?php echo e(URL::to('admin-galeri-all/')); ?>">Galeri</a>
                    </li>
                    <li class="active">
                        Semua Foto
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-sm-12">
                
                <?php if(Session::has('message')): ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <i class="fa fa-info-circle"></i>  <strong><?php echo e(Session::get('message')); ?></strong>
                </div>
                <?php endif; ?>

                <?php if(Session::has('destroy')): ?>
                <div class="alert alert-success alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <i class="fa fa-info-circle"></i>  <strong><?php echo e(Session::get('destroy')); ?></strong>
                </div>
                <?php endif; ?>

                <br>
                
<!--                <h3>Edit Galeri</h3>-->
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                    <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                        <thead>
                            <tr>
                                <th>Tanggal Buat</th>
                                <th>Judul</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($galeriAll[0] != null): ?>
                                <?php foreach($galeriAll as $index => $galeri): ?>
                                    <tr>
                                        <td><?php echo e($galeri->created_at); ?></td>
                                        <td><?php echo substr(strip_tags($galeri->judul), 0, 75) ?></td>
                                        <td>
                                            <a type="submit" class="btn btn-sm btn-primary" href="<?php echo e(URL::to('admin-galeri-view/'.$galeri->id_galeri)); ?>">Lihat</a>
                                            <a type="submit" class="btn btn-sm btn-danger" href="<?php echo e(URL::to('admin-galeri-delete/'.$galeri->id_galeri)); ?>">Hapus</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" style="text-align: center"><i>Tidak Ada Foto</i></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pager -->
                <div class="tabel-nav">
                    <div class="jumlah-data">
                        <strong> Jumlah foto: <?php echo e($jumlah); ?> 
                        </strong>
                    </div>
                    <div class="paging">
                        <?php echo e($galeriAll->links()); ?>

                    </div>
                </div>
                <!-- /.row -->

                <br>
                
                <div>
                    <a type="submit" class="btn btn-primary" href="<?php echo e(URL::to('admin-galeri-add/')); ?>" >Tambah Foto</a>
                </div>    
            
                <br><br><br><br>

            </div>

        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>